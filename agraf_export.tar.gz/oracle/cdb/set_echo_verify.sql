set echo off
set verify off
